// *****************************************************************
// this file is task for watchdog
//
// *****************************************************************

#pragma rtos_task watchdog_task

#include "kernel.h"
#include "kernel_id.h"
#include "typedefine.h"
#include "user.h"
#include "IntegrationTest.h"
#include "KickWatchdog.h"

static void initWatchdogTask(void);

/**
 * @brief watchdog task.
 * 
 * @param exinf[in] the information of task
 * @return none
 */
void watchdog_task(VP_INT exinf)
{
    FLGPTN	flgptn;
	initWatchdogTask();

	while(1)
	{
		wai_flg(ID_FLAG_WDT_TASK, WAIT_200MSEC_FLGPTN , TWF_ORW, (FLGPTN __FAR *)&flgptn);
        
        #if INTEGRATION_TEST
        countFunctionNum(FUN_KICK_WATCHDOG_WATCHDOG_TASK);
        #endif
        
		kickWatchdog();
	}
}

/**
 * @brief watchdog task initial
 * 
 * @param none
 * @return none
 */
static void initWatchdogTask(void)
{
#if INTEGRATION_TEST
	countFunctionNum(FUN_INIT_WATCHDOG_TASK);
#endif
	
	set_flg(ID_FLAG_SYSTEM_TASK, SET_WATCHDOG_START_END_FLGPTN);
}

