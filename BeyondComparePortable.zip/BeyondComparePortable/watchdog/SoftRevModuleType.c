// *****************************************************************
// this file is define software revision and module type
// 
// *****************************************************************
#include "typedefine.h"

#define PH_ROM_REV	0		/* PH ROM rev.100�{�f�[�^ */

#pragma	section	@@CNSTL	F_DATA

const USHORT __FAR	g_ushSoftRev = PH_ROM_REV;						/* Soft Rev	*/
const UCHAR  __FAR	CoverType[4] = { 0xC0 , 0x80 , 0xff , 0xff };	/* PH/DO	*/

