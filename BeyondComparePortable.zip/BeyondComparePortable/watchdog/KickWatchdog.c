// *****************************************************************
// this file is kick Watchdog
// 
// *****************************************************************
#pragma	sfr

#include "typedefine.h"
#include "KickWatchdog.h"

/*!------------------------------------------*
 *      unit test
 *-------------------------------------------*/
#ifdef UNIT_TEST_GMOCK
#include "KickWatchdogMock.h"
#include "RegisterMock.h"
void (*kickWatchdog)() = unitTest_kickWatchdog;
#endif


void FUNCTION kickWatchdog(void)
{
	WDTE=0xAC;
}