#!/usr/bin/env python

x = 0
print 'x is currently:', x
while x < 5:
    x += 1
    print 'incrementing x to:', x
